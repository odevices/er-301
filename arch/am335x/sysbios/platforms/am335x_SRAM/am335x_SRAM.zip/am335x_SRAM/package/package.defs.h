/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-G16
 */

#ifndef am335x_SRAM__
#define am335x_SRAM__



#endif /* am335x_SRAM__ */ 
